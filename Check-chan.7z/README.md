# Simple ludo game project.

# CHANGELOG <i>(all changes are shown below)</i>

# v0.0.3
- Added more logic to `CounterContainer`, `Dice`, `Player`, `Tile`, `Engine`, etc.
- Methods have been shortened to provide better standards.
# v0.0.2
 - Created basic classess for Player, Dice, Counter and CounterContainer.
 - Started creating game logic.
# v0.0.1
- Created the project
- Added <a href='https://github.com/nlohmann/json'>`JSON`</a> library