#include "Engine.hpp"
#include <iostream>

const std::string Engine::_VERSION = "0.1.2";

Engine::Engine():
	currentPlayer(-1),
	state(Engine::EngineStates::CREATED) {
	/*
	*			|
	*	*4*		|	 *1*
	*			|
	*-----------|----------
	*			|
	*	*3*		|	 *2*
	*			|
	*/
	Tile a(true);
	for (int i = 0; i < 4; ++i) {
		tiles[i * 13] = a; // Pola startowe graczy
		tiles[8 + i * 13] = a; // Pola dodatkowe
	}
}
Engine::~Engine() {
	for (auto p : players)
		delete players[p.first];
}

bool Engine::addPlayer(Player* player, unsigned int quarter) {
	if (state != EngineStates::CREATED) return false;
	for (auto p : players)
		if (p.second->getPlayer().getId() == player->getId())
			return false;
	
	if (quarter == 0 || quarter > 4)
		return false;
	players[quarter - 1] = new PlayerContainer(player, (quarter - 1) * 13);
	
	return true;	
}

void Engine::start()
{
	if (players.empty() || players.size() < 1) throw std::exception("Nie mo�na uruchomi� gry, zbyt ma�a liczba graczy!");
	if(state == EngineStates::CREATED) {
		currentPlayer = 0;
		state = EngineStates::STARTED;
	}
}

bool Engine::step() {
	if (finished())
		return true;
	if (state == EngineStates::CREATED) {
		std::cerr << "Nale�y rozpocz�� gr� przed wykonaniem kroku!\n";
		return false;
	}

	if (state == EngineStates::MOVE_MADE) {
		if(dice.getLast() != 6 || getCurrentPlayerContainer().allIn()) // Je�eli gracz nie wyrzuci� 6 lub zako�czy� gr�.
			do {
				currentPlayer += 1;
				currentPlayer %= players.size();
			} while (getCurrentPlayerContainer().allIn());
		
		state = EngineStates::STEP_MADE;
		
		return true;
	}
	return false;
}

unsigned int Engine::rollDice() {
	if (state == EngineStates::DICE_ROLLED || state == EngineStates::MOVE_MADE)
		return dice.getLast();
	state = EngineStates::DICE_ROLLED;
	return  dice.roll();
}


bool Engine::beatCountersToHolder(Tile& t) {
	std::vector<Counter*>::iterator it = t.lastBeat.begin();
	std::map<unsigned int, PlayerContainer*> mp;
	for (auto p : players)
		mp[p.second->getPlayer().getId()] = p.second;
	for (; it != t.lastBeat.end(); it++) {
		if (!mp[(*it)->getOwner()]->addToHolder(*it))
			return false;
	}
	t.lastBeat.clear();
	return t.lastBeat.size() == 0;
}

//~FIXME~: Naprawi� b��d podczas przechodzeia na pocz�tek planszy.
bool Engine::moveCounterOnBoard(unsigned int fieldNo) {
	Player& p = getCurrentPlayer();
	if (!tiles[fieldNo].hasCounter(p))
		return false;
	unsigned int offset = dice.getLast();
	bool result = tiles[fieldNo].movePlayerCounter(tiles[(fieldNo + offset) % 52], p);
	if (result)
		result |= beatCountersToHolder(tiles[(fieldNo + offset) % 52]);
	state = EngineStates::MOVE_MADE;
	return result;
}

//TODO: Sprawdzi� poruszanie si� po ostatnich.
bool Engine::moveCounterOnLast(unsigned int fieldNo) { 
	if (fieldNo <= 100 || fieldNo > 406) return false;
	unsigned int Q = fieldNo / 100 - 1;
	if (players.find(Q) == players.end())
		return false;
	PlayerContainer& c = *players[Q];
	if (c.getPlayer().getId() != getCurrentPlayer().getId())
		return false;
	unsigned int field = (fieldNo % 100) - 1;
	bool result = c.moveOnLast(field, dice.getLast());
	if(result)
		state = EngineStates::MOVE_MADE;
	return  result;
}

bool Engine::moveCounterToLast(unsigned int from, unsigned int offset) {
	std::vector<Counter*>& v = tiles[from].getCounters();
	PlayerContainer& c = getCurrentPlayerContainer();
	std::vector<Counter*>::iterator it = v.begin();
	for(;it!=v.end();it++)
		if ((*it)->getOwner() == c.getPlayer().getId())
		{
			Counter* ct = *it;
			v.erase(it);
			bool result = c.addToLast(ct, offset);
			if(result)
				state = EngineStates::MOVE_MADE;
			return result;
		}
	
	return false;
}



// 101-106 Q1
// 201-206 Q2
// 301-306 Q3
// 401-406 Q4

//~TODO~: Poprawi� metod� move() tak, by korzysta�a z nowych w�a�ciwo�ci Tile.

//bool Engine::move(unsigned int fieldNo) {
//
//	if (state != EngineStates::DICE_ROLLED) return false;
//	if (!getCurrentPlayerContainer().canMove() && dice.getLast() != 6) {
//		std::cout << "Cannot move!\n";
//		state = EngineStates::MOVE_MADE;
//		return false;
//	}
//	else if (dice.getLast() == 6) {
//		PlayerContainer& c = getCurrentPlayerContainer();
//		tiles[c.getStartPos()].addToTile(c.holderPop());
//		std::cout << "6 hit!\n";
//		state = EngineStates::MOVE_MADE;
//		return true;
//	}
//	if (fieldNo < 54)
//	{
//		std::cout << "Normal field!\n";
//		unsigned int distance = getDistance(getCurrentPlayerContainer(), dice.getLast());
//		if (distance > 52) 
//			return moveCounterToLast(fieldNo, distance - 52);
//		return moveCounterOnBoard(fieldNo);
//	}
//	else if(fieldNo > 100) {
//		std::cout << "Player special!\n";
//		return moveCounterOnLast(fieldNo);
//	}
//	return false;
//}

//TODO: Sprawdzi� czy dzia�a poprawnie.
//FIXME: Naprawi� b��d podczas przechodzenia na pocz�tek planszy.
bool Engine::move(unsigned int fieldNo) {
	if (state != EngineStates::DICE_ROLLED) return false;
	if (!getCurrentPlayerContainer().canMove() && dice.getLast() != 6) {
		state = EngineStates::MOVE_MADE;
		return false;
	}
	if (dice.getLast() == 6 && fieldNo == getCurrentPlayerContainer().getStartPos()) {
		PlayerContainer& pc = getCurrentPlayerContainer();
		Counter* c;
		if ((c = pc.holderPop()) != nullptr) // Je�li w domku by� pionek.
		{
			std::cout << "Popping from holder " << *c << '\n';
			bool result = tiles[pc.getStartPos()].addToTile(c);// Z za�o�enia wiele pionk�w mo�e na nim sta�.
			if (result)
				state = EngineStates::MOVE_MADE;
			else pc.addToHolder(c);
			return result; 
		}
	}
	if (fieldNo < 52) {
		unsigned int distance = getDistance(getCurrentPlayerContainer(), fieldNo + dice.getLast());
		std::cout << "Calculated distance is " << distance << '\n';
		if (distance < 50) {
			std::cout << "Moving on board to " << fieldNo + dice.getLast() << '\n';
			return moveCounterOnBoard(fieldNo);
		}
		std::cout << "Moving to last on " << distance - 50 << '\n';
		return moveCounterToLast(fieldNo, distance - 50);
	}
	else if (fieldNo > 100) {
		std::cout << "Moving on last " << fieldNo << '\n';
		return moveCounterOnLast(fieldNo);
	}
	return false;
}

bool Engine::finished() { 
	for (auto p : players) {
		if (!p.second->allIn())
			return false;
	}
	return true;
}


unsigned int Engine::getDistance(PlayerContainer& c, unsigned int dest) {
	if (c.getStartPos() < dest)
		return dest - c.getStartPos();
	return 52 + dest - c.getStartPos();
}



#ifdef _DEBUG
std::string Engine::stateToStr(Engine::EngineStates state) {
	switch (state) {
		case EngineStates::CREATED: return "CREATED";
		case EngineStates::STARTED: return "STARTED";
		case EngineStates::DICE_ROLLED: return "DICE_ROLLED";
		case EngineStates::STEP_MADE: return "STEP_MADE";
		case EngineStates::MOVE_MADE: return "MOVE_MADE";
		default: return "<UNKNOWN>";
	}
}
std::ostream& operator<< (std::ostream& os, const Engine& e) {
	std::cout << "<Engine object 0x" << std::hex << std::uppercase << &e << std::resetiosflags(std::ios_base::basefield) << " (v"<< Engine::_VERSION << ")>:\n";
	os << "Current state: " << std::boolalpha << Engine::stateToStr(e.state) << std::resetiosflags(std::ios_base::basefield) << '\n';
	os << "PlayerContainers:\n[";
	for (auto p : e.players)
		os << *p.second << ", \n";
	os << "]\n";
	os << "Tiles: [\n";
	unsigned int index = 0;
	for (auto& i : e.tiles)
		os << '[' << index++ << "]: " << i << '\n';
	os << "]\n";
	return os;
}
#endif